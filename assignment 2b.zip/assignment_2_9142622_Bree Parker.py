
#-----Statement of Authorship----------------------------------------#
#
#  This is an individual assessment item for QUT's teaching unit
#  IFB104, "Building IT Systems", Semester 1, 2024.  By submitting
#  this code I agree that it represents my own work.  I am aware of
#  the University rule that a student must not act in a manner
#  which constitutes academic dishonesty as stated and explained
#  in QUT's Manual of Policies and Procedures, Section C/5.3
#  "Academic Integrity" and Section E/2.1 "Student Code of Conduct".
#
#  Put your student number here as an integer and your name as a
#  character string:
#
student_number = 9142622
student_name   = "Bree"
#
#  NB: Files submitted without a completed copy of this statement
#  will not be marked.  All files submitted will be subjected to
#  software plagiarism analysis using the MoSS system
#  (http://theory.stanford.edu/~aiken/moss/).
#
#--------------------------------------------------------------------#



#-----Assessment Task 2 Description----------------------------------#
#
#  In this assessment task you will combine your knowledge of Python
#  programming, HTML-style mark-up languages, pattern matching,
#  database management, and Graphical User Interface design to produce
#  a robust, interactive "app" that allows its user to view and save
#  data from multiple online sources.
#
#  See the client's briefings accompanying this file for full
#  details.
#
#  Note that this assessable assignment is in multiple parts,
#  simulating incremental release of instructions by a paying
#  "client".  This single template file will be used for all parts,
#  together with some non-Python support files.
#
#--------------------------------------------------------------------#



#-----Set up---------------------------------------------------------#
#
# This section imports standard Python 3 modules sufficient to
# complete this assignment.  Don't change any of the code in this
# section, but you are free to import other Python 3 modules
# to support your solution, provided they are standard ones that
# are already supplied by default as part of a normal Python/IDLE
# installation.
#
# However, you may NOT use any Python modules that need to be
# downloaded and installed separately, such as "Beautiful Soup" or
# "Pillow", because the markers will not have access to such modules
# and will not be able to run your code.  Only modules that are part
# of a standard Python 3 installation may be used.

# A function for exiting the program immediately (renamed
# because "exit" is already a standard Python function).
from sys import exit as abort

# A function for opening a web document given its URL.
# [You WILL need to use this function in your solution,
# either directly or via the "download" function below.]
from urllib.request import urlopen

# Some standard Tkinter functions.  [You WILL need to use
# SOME of these functions in your solution.]  You may also
# import other widgets from the "tkinter" module, provided they
# are standard ones and don't need to be downloaded and installed
# separately.  (NB: Although you can import individual widgets
# from the "tkinter.tkk" module, DON'T import ALL of them
# using a "*" wildcard because the "tkinter.tkk" module
# includes alternative versions of standard widgets
# like "Label" which leads to confusion.  If you want to use
# a widget from the tkinter.ttk module name it explicitly,
# as is done below for the progress bar widget.)
from tkinter import *
from tkinter.scrolledtext import ScrolledText
from tkinter.ttk import Progressbar

# Functions for finding occurrences of a pattern defined
# via a regular expression.  [You do not necessarily need to
# use these functions in your solution, because the problem
# may be solvable with the string "find" function, but it will
# be difficult to produce a concise and robust solution
# without using regular expressions.]
from re import *

# A function for displaying a web document in the host
# operating system's default web browser (renamed to
# distinguish it from the built-in "open" function for
# opening local files).  [You WILL need to use this function
# in your solution.]
from webbrowser import open as urldisplay

# All the standard SQLite database functions.  [You WILL need
# to use some of these in your solution.]
from sqlite3 import *

#
#--------------------------------------------------------------------#



#-----Validity Check-------------------------------------------------#
#
# This section confirms that the student has declared their
# authorship.  You must NOT change any of the code below.
#

if not isinstance(student_number, int):
    print('\nUnable to run: No student number supplied',
          '(must be an integer)\n')
    abort()
if not isinstance(student_name, str):
    print('\nUnable to run: No student name supplied',
          '(must be a character string)\n')
    abort()

#
#--------------------------------------------------------------------#



#-----Supplied Function----------------------------------------------#
#
# Below is a function you can use in your solution if you find it
# helpful.  You are not required to use this function, but it may
# save you some effort.  Feel free to modify the function or copy
# parts of it into your own code.
#

# A function to download and save a web document.  The function
# returns the downloaded document as a character string and
# optionally saves it as a local file.  If the attempted download
# fails, an error message is written to the shell window and the
# special value None is returned.  However, the root cause of the
# problem is not always easy to diagnose, depending on the quality
# of the response returned by the web server, so the error
# messages generated by the function below are indicative only.
#
# Parameters:
# * url - The address of the web page you want to download.
# * target_filename - Name of the file to be saved (if any).
# * filename_extension - Extension for the target file, usually
#      "html" for an HTML document or "xhtml" for an XML
#      document.
# * save_file - A file is saved only if this is True. WARNING:
#      The function will silently overwrite the target file
#      if it already exists!
# * char_set - The character set used by the web page, which is
#      usually Unicode UTF-8, although some web pages use other
#      character sets.
# * incognito - If this parameter is True the Python program will
#      try to hide its identity from the web server. This can
#      sometimes be used to prevent the server from blocking access
#      to Python programs. However we discourage using this
#      option as it is both unreliable and unethical to
#      override the wishes of the web document provider!
#
def download(url = 'https://www.theage.com.au/',
             target_filename = 'downloaded_document1',
             filename_extension = 'html',
             save_file = True,
             char_set = 'UTF-8',
             incognito = False):

    # Import the function for opening online documents and
    # the class for creating requests
    from urllib.request import urlopen, Request

    # Import an exception sometimes raised when a web server
    # denies access to a document
    from urllib.error import HTTPError

    # Import an exception raised when a web document cannot
    # be downloaded due to some communication error
    from urllib.error import URLError

    # Open the web document for reading (and make a "best
    # guess" about why if the attempt fails, which may or
    # may not be the correct explanation depending on how
    # well behaved the web server is!)
    try:
        if incognito:
            # Pretend to be a web browser instead of
            # a Python script (not recommended!)
            request = Request(url)
            request.add_header('User-Agent',
                               'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; ' + \
                               'rv:91.0; ADSSO) Gecko/20100101 Firefox/91.0')
            print("Warning - Request to server does not reveal client's true identity.")
            print("          Use this option only if absolutely necessary!\n")
        else:
            # Behave ethically
            request = url
        web_page = urlopen(request)
    except ValueError as message: # probably a syntax error
        print(f"\nCannot find requested document '{url}'")
        print(f"Error message was: {message}\n")
        return None
    except HTTPError as message: # possibly an authorisation problem
        print(f"\nAccess denied to document at URL '{url}'")
        print(f"Error message was: {message}\n")
        return None
    except URLError as message: # probably the wrong server address
        print(f"\nCannot access web server at URL '{url}'")
        print(f"Error message was: {message}\n")
        return None
    except Exception as message: # something entirely unexpected
        print("\nSomething went wrong when trying to download " + \
              f"the document at URL '{str(url)}'")
        print(f"Error message was: {message}\n")
        return None

    # Read the contents as a character string
    try:
        web_page_contents = web_page.read().decode(char_set)
    except UnicodeDecodeError as message:
        print("\nUnable to decode document from URL " + \
              f"'{url}' as '{char_set}' characters")
        print(f"Error message was: {message}\n")
        return None
    except Exception as message:
        print("\nSomething went wrong when trying to decode " + \
              f"the document from URL '{url}'")
        print(f"Error message was: {message}\n")
        return None

    # Optionally write the contents to a local text file
    # (silently overwriting the file if it already exists!)
    if save_file:
        try:
            text_file = open(f'{target_filename}.{filename_extension}',
                             'w', encoding = char_set)
            text_file.write(web_page_contents)
            text_file.close()
        except Exception as message:
            print(f"\nUnable to write to file '{target_filename}'")
            print(f"Error message was: {message}\n")

    # Return the downloaded document to the caller
    return web_page_contents

#
#--------------------------------------------------------------------#



#-----Student's Solution---------------------------------------------#
#
# Put your solution below.
#

# Create the main window
from urllib.request import urlopen
import sqlite3
import urllib.error
import re
import webbrowser


#Initialising GUI
root = Tk()
root.geometry("1000x800")

root.title('60% of the time it works every time')
frame = Frame(root, bg='coral', width=1000, height=1000)
frame.grid()

#placing the Labelframes
labelframe = LabelFrame(frame, text= "View stories", fg = 'white', bg = 'coral', font=(None, 15))
labelframe3 = LabelFrame(frame, text = "Messages", fg = 'white', font=(None, 15), bg = 'coral')
labelframe4 = LabelFrame(frame, text = "Find Stories", fg = 'white', font=(None, 15), bg ='coral')
labelframe5 = LabelFrame(frame, text = "Data reliability", fg = 'white', font=(None, 15), bg = "coral")
labelframe6 = LabelFrame(frame, fg = 'white', font=(None, 15), bg = "coral", width = 512, height = 512)
labelframe7 = LabelFrame(labelframe3, text = "news", fg = 'white', font=(None, 15), bg = 'light grey')
labelframe4.grid(row = 0, column= 1, sticky = 'NW')
labelframe.grid(row = 0, column= 1, padx = 0, pady = 200, sticky = 'NW',)
labelframe3.grid(row = 0, column= 0, padx = 0, pady = 0, sticky ='N',)
labelframe5.grid(row = 0, column= 0, padx = 10, pady = 420, rowspan= 5, sticky ='NW')
labelframe6.grid(row = 0, column= 1, padx = 10, pady = 260, rowspan= 5, sticky ='NW')
labelframe7.grid(row = 0, column= 0, padx = 0, pady = 100, sticky ='NSEW')

def create_headline_dateline_labels():
    global headline_label, dateline_label
    headline_label = Label(labelframe7, text="", font=(None, 12))
    headline_label.grid(row=0, column=0, padx=10, pady=10, sticky=W)
    dateline_label = Label(labelframe7, text="", font=(None, 12), fg="grey")
    dateline_label.grid(row=1, column=0, padx=10, pady=5, sticky=W)


# labels inside of labelframes    
label_text = "Reliability scale"
label = Label(labelframe5, text=label_text, bg = "coral", fg = "white", font=(None, 20))
label.grid(row = 0, column = 0, padx = 0, pady = 0, sticky = "N")

label_text = "Not reliable"
label = Label(labelframe5, text=label_text, bg = "coral", fg = "black", font=(None, 20))
label.grid(row = 2, column = 0, padx = 0, pady = 0, sticky = "E")

label_text = "Reliable"
label = Label(labelframe5, text=label_text, bg = "coral", fg = "black", font=(None, 20))
label.grid( row = 2, column = 0, padx = 0, pady = 0, sticky = "W")


# Images within the labelframes
img1 = PhotoImage(file = "brisbane times.png")
img2 = PhotoImage(file = "sydney.png")
img3 = PhotoImage(file="theage.png")
img4 = PhotoImage(file = "anchorman.png")

label2 = Label(labelframe6, image=img4)
label2.grid(row = 0, column = 0, padx=10, pady=10)
v = StringVar()

#Data scraping 
def download(url=None):
    try:
        if url is None:
            return ""
        response = urllib.request.urlopen(url)
        html_content = response.read().decode('utf-8')

        save_html_to_file(html_content)

        return html_content
    except urllib.error.HTTPError as e:
        if e.code == 403:
            print(f"Access denied to document at URL '{url}'")
        else:
            print(f"HTTP Error: {e}")
    except Exception as e:
            print(f"Error downloading the webpage: {e}")
    return ""
      
# Saving Pulled Data        
def save_html_to_file(html_content):
    file_name = "download_{website_name}_website.html"
    with open(file_name, 'w', encoding='utf-8') as file:
        file.write(html_content)
        
# Accessing online data
def fetch_brisbane_news():
    try:
        url = "https://www.brisbanetimes.com.au/"
        response = urllib.request.urlopen(url)
        html = response.read().decode('utf-8')

        print("HTML content for Brisbane news:", html)

        headline_pattern = re.compile(r'<h3 class="_2XVos _2FhIH" data-testid="article-headline" data-pb-type="hl"><a [^>]*>(.*?)</a></h3>', re.DOTALL)
        dateline_pattern = re.compile(r'<time class="Cl81a"><span class="_18OHW">.*?</span>(.*?)</time>', re.DOTALL)

        headline = headline_pattern.search(html)
        dateline = dateline_pattern.search(html)

        headline_text = headline.group(1) if headline else "Headline not found"
        dateline_text = dateline.group(1) if dateline else "Dateline not found"

        print("Headline match:", headline)
        print("Dateline match:", dateline)

        return headline_text, dateline_text
    except Exception as e:
        print(f"Error fetching Brisbane news: {e}")
        return "", ""

def fetch_sydney_news():
    try:
        url = "https://www.smh.com.au/"
        response = urllib.request.urlopen(url)
        html = response.read().decode('utf-8')

        print("HTML content for Sydney news:", html)
        
        headline_pattern = re.compile(r'<h3 class="_2XVos _399UA" data-testid="article-headline" data-pb-type="hl"><a[^>]+>(.*?)</a></h3>', re.DOTALL)
        dateline_pattern = re.compile(r'<time class="Cl81a"><span class="_18OHW">.*?</span>(.*?)</time>', re.DOTALL)

        headline_match = headline_pattern.search(html)
        dateline_match = dateline_pattern.search(html)

        headline_text = headline_match.group(1) if headline_match else "Headline not found"
        dateline_text = dateline_match.group(1) if dateline_match else "Dateline not found"

        print("Extracted headline for Sydney news:", headline_text)
        print("Extracted dateline for Sydney news:", dateline_text)

        return headline_text, dateline_text
    except Exception as e:
        print(f"Error fetching Sydney news: {e}")
        return "", ""

def fetch_canberra_news():
    try:
        url = "https://www.theage.com.au/"
        response = urllib.request.urlopen(url)
        html = response.read().decode('utf-8')

        print("HTML content for The Age:", html)

        headline_pattern = re.compile(r'<h3 class="_2XVos _399UA" data-testid="article-headline" data-pb-type="hl"><a data-testid="article-link" href="[^"]*">([^<]*)</a></h3>')
        dateline_pattern = re.compile(r'<time class="Cl81a"><span class="_18OHW">.*?</span>(.*?)</time>')

        headline_match = headline_pattern.search(html)
        dateline_match = dateline_pattern.search(html)

        headline_text = headline_match.group(1) if headline_match else "Headline not found"
        dateline_text = dateline_match.group(1) if dateline_match else "Dateline not found"

        print("Extracted headline for The Age:", headline_text)
        print("Extracted dateline for The Age:", dateline_text)

        return headline_text, dateline_text
    except Exception as e:
        print(f"Error fetching The Age news: {e}")
        return "", ""

# Creating Database
def create_database():
    try:
        with sqlite3.connect("urls.db") as conn:
            c = conn.cursor()
            c.execute('''CREATE TABLE IF NOT EXISTS urls
                  (id INTEGER PRIMARY KEY, option TEXT, url TEXT, reliability_rating INTEGER)''')
            c.execute('''CREATE TABLE IF NOT EXISTS ratings
                  (id INTEGER PRIMARY KEY, source TEXT, headline TEXT, dateline TEXT, rating INTEGER)''')
    except sqlite3.Error as e:
        print(f"Error creating database: {e}")
create_database()

#saving data to the database
def insert_urls():
    try:
        with sqlite3.connect("urls.db") as conn:
            c = conn.cursor()
            c.execute("SELECT COUNT(*) FROM urls")
            existing_rows = c.fetchone()[0]
            if existing_rows >= 3:
                print("URLs already exist in the table")
                return
            urls_to_insert = [
                ("News in Brisbane", "https://www.brisbanetimes.com.au/", 0),
                ("News in Sydney", "https://www.smh.com.au/", 0),
                ("News from The Age", "https://www.theage.com.au/", 0),
            ]
            for option, url, rating in urls_to_insert:
                c.execute("INSERT OR IGNORE INTO urls (option, url, reliability_rating) VALUES (?, ?, ?)",
                          (option, url, rating))
            conn.commit()
            print("URLs inserted successfully.")
    except Exception as e:
        print(f"Error inserting URLs: {e}")


def get_url(selected_value):
    try:
        with sqlite3.connect("urls.db") as conn:
            c = conn.cursor()
            c.execute("SELECT url FROM urls WHERE option=?", (selected_value,))
            result = c.fetchone()
        return result[0] if result else None
    except Exception as e:
        print(f"Error getting URL: {e}")
        return None
    
# Updating the databse when running module
def update():
    selected_value = v.get()
    url = get_url(selected_value)
    if url:
        try:
            html_content = download(url)
            if html_content:
                if selected_value == "News in Brisbane":
                    headline, dateline = fetch_brisbane_news()
                elif selected_value == "News in Sydney":
                    headline, dateline = fetch_sydney_news()
                elif selected_value == "News from The Age":
                    headline, dateline = fetch_canberra_news()
                headline_label.config(text=f"Headline: {headline}")
                dateline_label.config(text=f"Dateline: {dateline}")
            else:
                print("Failed to download webpage.")
        except urllib.error.HTTPError as e:
            if e.code == 403:
                print("Access denied to document at URL '{}'".format(url))
                print("Error message was:", e)
                print("Failed to download webpage.")
            else:
                print("HTTP Error:", e)
    else:
        print("Invalid selection or URL not available.")

#accessing website data through the GUI
def open_website():
    selected_value = v.get()
    url = get_url(selected_value)
    if url:
        webbrowser.open_new(url)
    else:
        print("Invalid selection")

def create_radio_buttons():
    rb1 = Radiobutton(labelframe4, font=(None, 10), image=img1, command=update, variable=v, bg = 'coral', value="News in Brisbane")
    rb1.grid(row=1, column=0, columnspan=3, padx=10, pady=10)
    rb2 = Radiobutton(labelframe4, font=(None, 10), image=img2, command=update, variable=v, bg = 'coral', value="News in Sydney")
    rb2.grid(row=2, column=0, columnspan=3, padx=10, pady=10)
    rb3 = Radiobutton(labelframe4, font=(None, 10), image=img3, command=update, variable=v, bg = 'coral', value="News from The Age")
    rb3.grid(row=3, column=0, columnspan=3, padx=10, pady=10)
def save_rating():
    select_value= v.get()
    rating = scale_var.get()
    try:
        with sqlite3.connect("urls.db") as conn:
            c = conn.cursor()
            c.execute("UPDATE urls SET reliability_rating = ?", (rating, selected_value))
    except Exception as e:
            print(f"Error saving rating: {e}")


def print_story():
    update()
    
    open_website_button = Button(labelframe4, text="Open Website", command=open_website)
    open_website_button.grid(row=4, column=1, padx=0, pady=0, sticky = 'WS')


    print_story_button = Button(labelframe4, text="Show latest", command=update)
    print_story_button.grid(row=4, column=1, padx=0, pady=0, sticky = 'ES')

scale_var = DoubleVar()
rating_scale = Scale(labelframe5, from_=0, to=5, orient='horizontal', variable=scale_var, length=300)
rating_scale.grid(row=1, column=0, padx=100, pady=0, sticky = 'SE')
save_button = Button(labelframe5, text="Save Rating", command=save_rating)
save_button.grid(row=2, column=0, padx=0, pady=0)

headline_label = None
dateline_label = None

create_headline_dateline_labels()
create_radio_buttons()
print_story()
insert_urls()

root.mainloop()


# Your code goes here


# Start the event loop to detect user inputs

